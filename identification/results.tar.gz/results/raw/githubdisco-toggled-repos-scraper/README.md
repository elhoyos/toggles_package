round_2: all but Python, .NET, Ruby, Objective-C
round_3: all, with fixes in discarded languages from round_2